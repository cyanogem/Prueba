﻿namespace PersonasBAL
{
    public class Class1
    {

    }
}