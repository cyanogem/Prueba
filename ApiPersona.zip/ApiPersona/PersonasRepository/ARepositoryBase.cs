﻿using Abp.Domain.Entities;
using ApiPersona.Models.Personas;
using Castle.Core.Logging;
using Lw.Data.Entity;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonasRepository
{
    public  interface IARepositoryBase<T> : ICRUD<T>
    {

    }
    public abstract class ARepositoryBase<T>: IARepositoryBase<T> where T : IEntity
    {
        ILogger logger;
        PruebaPersonasContext db;

        public ARepositoryBase(ILogger<ARepositoryBase<T>> _logger, IDBContext<T> context, PruebaPersonasContext db)
        {
            this.logger = logger;
            this.db = db;
        }

        public void DeleteById(int id)
        {
            throw new NotImplementedException();
        }

        public IList<T> GetAll()
        {
            throw new NotImplementedException();
        }

        public IList<T> GetAllByPage(int page, int pageSize)
        {
            throw new NotImplementedException();
        }

        public T GetById(int id)
        {
            throw new NotImplementedException();
        }

        public T Save(T entity)
        {
            throw new NotImplementedException();
        }

        public T Update(T entity)
        {
            throw new NotImplementedException();
        }
    }
}
