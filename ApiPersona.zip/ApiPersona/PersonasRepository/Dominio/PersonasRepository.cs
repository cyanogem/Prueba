﻿using ApiPersona.Models.Personas;
using Castle.Core.Logging;
using Lw.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonasRepository.Dominio
{
    public class PersonasRepository<T> : ARepositoryBase where T : Persona
    {
        ILogger logger;
        IDbContext<T> dbContext;
        PruebaPersonasContext db;

        public PersonasRepository(ILogger logger, Lw.Data.Entity.IDbContext<T> dbContext, PruebaPersonasContext db)
        {
            this.logger = logger;
            this.dbContext = dbContext;
            this.db = db;
        }

        public T Save(T entity)
        {
            return this.dbContext.Save(entity);

        }

        public List<Persona> ListPersonas()
        {
            List<Persona> personas = (from p in db.Personas
                                      select new Persona()
                                      {
                                          IdPersonas = p.IdPersonas,
                                          Documento= p.Documento,
                                          Nombres = p.Nombres,
                                          Apellidos = p.Apellidos,
                                          Telefono = p.Telefono,
                                          Correo = p.Correo,
                                          Direccion = p.Direccion,

                                      }).ToList();
            return personas;
        }

    }
}
