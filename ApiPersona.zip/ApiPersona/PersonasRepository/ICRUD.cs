﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonasRepository
{
        public interface ICRUD<T>
    {
        T GetById(int id);
        IList<T> GetAll();

        IList<T> GetAllByPage(int page, int pageSize);

        T Save(T entity);

        T Update(T entity);

        void DeleteById(int id);


    }
}
