﻿using System;
using System.Collections.Generic;

namespace ApiPersona.Models.Personas;

public partial class Persona
{
    public int IdPersonas { get; set; }

    public string? Documento { get; set; }

    public string? Nombres { get; set; }

    public string? Apellidos { get; set; }

    public string? Telefono { get; set; }

    public string? Correo { get; set; }

    public string? Direccion { get; set; }
}
